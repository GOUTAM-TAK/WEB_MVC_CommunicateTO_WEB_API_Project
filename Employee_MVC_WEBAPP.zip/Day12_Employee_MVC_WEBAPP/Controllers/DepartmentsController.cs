﻿using Day12_Employee_MVC_WEBAPP.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Day12_Employee_MVC_WEBAPP.Controllers
{

    public class DepartmentsController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public DepartmentsController(IHttpClientFactory httpClientFactory)
        {
           _httpClientFactory = httpClientFactory;
        }

        
        // GET: DepartmentsController
        public async Task<ActionResult> Index()
        {
               var client=_httpClientFactory.CreateClient("api");
            var response = await client.GetAsync("Departments");
            if(response.IsSuccessStatusCode)
            {
                var item = await response.Content.ReadFromJsonAsync<List<Department>>();
                Console.WriteLine("success");
                return View(item);
            }
            
            return RedirectToAction();
        }

        // GET: Departments/Details/5
        public async  Task<ActionResult> Details(short id)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"Departments/{id}");
            if (response.IsSuccessStatusCode)
            {
                var item = await response.Content.ReadFromJsonAsync<Department>();
                Console.WriteLine("success");
                return View(item);
            }

            return View();
        }

        // GET: DepartmentsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Departments/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Department dept)
        {
            var client = _httpClientFactory.CreateClient("api");
            try
            {
                var response = await client.PostAsJsonAsync<Department>("Departments", dept);
                if(response.IsSuccessStatusCode)
                {
                    var item = response.Content.ReadFromJsonAsync<Department>();

                    Department d = item.Result;
                    Console.WriteLine(d);
                    Console.WriteLine("success5");
                    Console.WriteLine(response.ToString());
                  
                    return RedirectToAction("Index");
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Departments/Edit/5
        public async Task<ActionResult> Edit(short id)//binding concept datatype must be match
        {
            var client = _httpClientFactory.CreateClient("api");
           var response=await client.GetAsync($"Departments/{id}");
            if(response.IsSuccessStatusCode)
            {
                var item= await response.Content.ReadFromJsonAsync<Department>();
               return View(item);
            }
            else
            return RedirectToAction("Index");
        }

        // POST: Departments/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(short id, Department dept)
        {
            var client = _httpClientFactory.CreateClient("api");
            try
            {
                var response=await client.PutAsJsonAsync($"Departments/{id}", dept);
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("success in update");
                    TempData.Add("msg", "success in update");

                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: DepartmentsController/Delete/5
        public async Task<ActionResult> Delete(short id)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"Departments/{id}");
            if (response.IsSuccessStatusCode)
            {
                var item = await response.Content.ReadFromJsonAsync<Department>();
               return View(item);
            }
            else
            return RedirectToAction("Index");
        }

        // POST: DepartmentsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(short? id)
        {
            var client = _httpClientFactory.CreateClient("api");
            try
            {
                var response = await client.DeleteAsync($"Departments/{id}");//Not use json type method
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("success in update");
                    return RedirectToAction(nameof(Index));
                }
                else
                return View();
            }
            catch
            {
                return View();
            }
        }
    }
}
