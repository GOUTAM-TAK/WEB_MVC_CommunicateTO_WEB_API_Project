﻿namespace Day12_Employee_MVC_WEBAPP.Models
{
    public class Department
    {
        public string Name { get; set; } = null!;

        public short Deptno { get; set; }
        public override string ToString()
        {
            return Name + " " + Deptno;
        }
    }
    }
