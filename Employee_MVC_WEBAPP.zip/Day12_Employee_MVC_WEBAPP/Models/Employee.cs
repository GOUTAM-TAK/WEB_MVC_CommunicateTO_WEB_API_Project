﻿namespace Day12_Employee_MVC_WEBAPP.Models
{
    public class Employee
    {
      
            public int Empno { get; set; }

            public string Name { get; set; } = null!;

            public decimal Basic { get; set; }

            public short Deptno { get; set; }
        }
}
