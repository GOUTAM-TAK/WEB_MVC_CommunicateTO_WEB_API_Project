
using day12__WebApi_practice.Models;
using Microsoft.EntityFrameworkCore;

namespace day12__WebApi_practice
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            builder.Services.AddDbContext<EmployeeDatabaseContext>(options =>
                       options.UseSqlServer(builder.Configuration.GetConnectionString("EmployeeDatabase")));
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddCors(c => c.AddDefaultPolicy(defpolicy => { defpolicy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader(); }));

            var app = builder.Build();
            app.UseCors();//enable cross origin services

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}