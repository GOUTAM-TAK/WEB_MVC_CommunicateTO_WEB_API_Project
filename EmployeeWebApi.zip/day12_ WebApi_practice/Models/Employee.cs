﻿using System;
using System.Collections.Generic;

namespace day12__WebApi_practice.Models;

public partial class Employee
{
    public int Empno { get; set; }

    public string Name { get; set; } = null!;

    public decimal Basic { get; set; }

    public short Deptno { get; set; }

    public virtual Department DeptnoNavigation { get; set; } = null!;
}
