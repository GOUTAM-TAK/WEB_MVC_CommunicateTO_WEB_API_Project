﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace day12__WebApi_practice.Models;

public partial class Department
{
    public string Name { get; set; } = null!;

    public short Deptno { get; set; }
    
    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}
