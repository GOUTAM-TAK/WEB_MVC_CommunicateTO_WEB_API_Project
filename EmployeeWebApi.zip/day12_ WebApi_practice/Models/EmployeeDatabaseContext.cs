﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace day12__WebApi_practice.Models;

public partial class EmployeeDatabaseContext : DbContext
{
    public EmployeeDatabaseContext()
    {
    }

    public EmployeeDatabaseContext(DbContextOptions<EmployeeDatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MsSqlLocalDb;Initial Catalog=EmployeeDatabase;Integrated Security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.Deptno);

            entity.Property(e => e.Deptno).HasColumnName("deptno");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Empno).HasName("PK__tmp_ms_x__AF4C318AA3B28EEA");

            entity.Property(e => e.Empno).HasColumnName("empno");
            entity.Property(e => e.Basic)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("basic");
            entity.Property(e => e.Deptno).HasColumnName("deptno");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");

            entity.HasOne(d => d.DeptnoNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.Deptno)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Employees_ToTable");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
